package pl.edu.agh.mwo.java2.sampleapp;

import javafx.application.Application;
import javafx.stage.Stage;
import pl.edu.agh.mwo.java2.sampleapp.presenter.AccountPresenter;

public class Main extends Application {

	private Stage primaryStage;
	
	private AccountPresenter presenter;

	@Override
	public void start(Stage primaryStage) {

		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("My first JavaFX app");

		this.presenter = new AccountPresenter(primaryStage);
		this.presenter.initRootLayout();

	}

	public static void main(String[] args) {
		launch(args);
	}
}
