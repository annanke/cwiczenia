package pl.edu.agh.mwo.java2.sampleapp.presenter;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import pl.edu.agh.mwo.java2.sampleapp.Main;
import pl.edu.agh.mwo.java2.sampleapp.command.CommandRegistry;
import pl.edu.agh.mwo.java2.sampleapp.model.Transaction;
import pl.edu.agh.mwo.java2.sampleapp.model.generator.DataGenerator;
import pl.edu.agh.mwo.java2.sampleapp.view.AccountOverviewController;
import pl.edu.agh.mwo.java2.sampleapp.view.TransactionEditDialogController;

public class AccountPresenter {

	private Stage primaryStage;

	private CommandRegistry commandRegistry = new CommandRegistry();

	public AccountPresenter(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	public void initRootLayout() {
		try {
			this.primaryStage.setTitle("My second JavaFX app");

			// load layout from FXML file
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class
					.getResource("view/AccountOverviewPane.fxml"));
			BorderPane rootLayout = (BorderPane) loader.load();

			// set initial data into controller
			AccountOverviewController controller = loader.getController();
			controller.setPresenter(this);
			controller.setData(DataGenerator.generateAccountData());
			controller.setCommandRegistry(commandRegistry);

			// add layout to a scene and show them all
			Scene scene = new Scene(rootLayout);
			primaryStage.setScene(scene);
			primaryStage.show();

		} catch (IOException e) {
			// don't do this in common apps
			e.printStackTrace();
		}

	}

	public boolean showTransactionEditDialog(Transaction transaction) {
		try {
			// Load the fxml file and create a new stage for the dialog
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class
					.getResource("view/TransactionEditDialog.fxml"));
			BorderPane page = (BorderPane) loader.load();

			// Create the dialog Stage.
			Stage dialogStage = new Stage();
			dialogStage.setTitle("Edit transaction");
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(primaryStage);
			Scene scene = new Scene(page);
			dialogStage.setScene(scene);

			// Set the person into the controller.
			TransactionEditDialogController controller = loader.getController();
			controller.setDialogStage(dialogStage);
			controller.setData(transaction);

			// Show the dialog and wait until the user closes it
			dialogStage.showAndWait();
			return controller.isApproved();

		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
}
