package pl.edu.agh.mwo.java2.sampleapp.command;

public interface Command {

	void execute();

	void undo();

	void redo();

	String getName();
}
