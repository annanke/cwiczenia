package pl.edu.agh.mwo.java2.sampleapp.command;

import pl.edu.agh.mwo.java2.sampleapp.model.Account;
import pl.edu.agh.mwo.java2.sampleapp.model.Transaction;

public class AddTransactionCommand implements Command {

	private Transaction transactionToAdd;

	private Account account;

	public AddTransactionCommand(Transaction transactionToAdd, Account account) {
		this.transactionToAdd = transactionToAdd;
		this.account = account;
	}

	@Override
	public void execute() {
		account.addTransaction(transactionToAdd);
	}

	@Override
	public String getName() {
		return "New transaction: " + transactionToAdd.toString();
	}

	@Override
	public void undo() {
		account.removeTransaction(transactionToAdd);
	}

	@Override
	public void redo() {
		execute();
	}
}
