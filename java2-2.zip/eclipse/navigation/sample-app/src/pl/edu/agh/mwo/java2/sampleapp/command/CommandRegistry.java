package pl.edu.agh.mwo.java2.sampleapp.command;

import java.util.ArrayDeque;
import java.util.Deque;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class CommandRegistry {

	private ObservableList<Command> commandStack = FXCollections
			.observableArrayList();

	private Deque<Command> undoneCommands = new ArrayDeque<>();

	public void executeCommand(Command command) {
		command.execute();
		commandStack.add(command);
		undoneCommands.clear();
	}

	public void redo() {
		if (canRedo()) {
			Command lastCommand = undoneCommands.pop();
			lastCommand.redo();
			commandStack.add(lastCommand);
		}
	}

	public void undo() {
		if (canUndo()) {
			Command lastCommand = commandStack.remove(commandStack.size() - 1);
			lastCommand.undo();
			undoneCommands.push(lastCommand);
		}
	}

	public boolean canUndo() {
		return !commandStack.isEmpty();
	}

	public boolean canRedo() {
		return !undoneCommands.isEmpty();
	}

	public ObservableList<Command> getCommandStack() {
		return commandStack;
	}
}
