package pl.edu.agh.mwo.java2.sampleapp.command;

import java.util.ArrayList;
import java.util.List;

import pl.edu.agh.mwo.java2.sampleapp.model.Account;
import pl.edu.agh.mwo.java2.sampleapp.model.Transaction;

public class RemoveTransactionsCommand implements Command {

	private Account account;
	private List<Transaction> transactionsToRemove;

	public RemoveTransactionsCommand(Account account,
			List<Transaction> transactionToRemove) {
		this.account = account;
		this.transactionsToRemove = new ArrayList<>(transactionToRemove);
	}

	@Override
	public void execute() {
		account.getTransactions().removeAll(transactionsToRemove);
	}

	@Override
	public String getName() {
		return transactionsToRemove.size() + " transactions removed.";
	}

	@Override
	public void undo() {
		account.getTransactions().addAll(transactionsToRemove);
	}

	@Override
	public void redo() {
		execute();
	}

}
